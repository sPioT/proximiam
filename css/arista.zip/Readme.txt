[z]fonts - Truetype Fonts
(c) 2007 by studio Kmzero - [z]fonts 
[http://www.zetafonts.com]

This font is free for personal, non-commercial use.
Donations are accepted and highly appreciated! [http://www.zetafonts.com/donate.php]

To use our fonts for commercial and profit purposes buy this font on myfonts.com
[http://www.myfonts.com/foundry/zetafonts/]
or buy our special ego[n] pack, comprising 18 fonts and included in ego[n] magazine
[http://www.egonmagazine.com]

Studio kmzero font website is
[http://www.zetafonts.com]

Studio kmzero corporate website is
[http://www.studiokmzero.com]
Contact: info@studiokmzero.com

All trademarks are property of their respective owners.